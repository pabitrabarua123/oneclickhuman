import TextGeneratorPage from "./index";

export const metadata = {
  title: "Text Generator - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const TextGeneratorLayout = () => {
  return (
    <>
      <TextGeneratorPage />
    </>
  );
};

export default TextGeneratorLayout;
