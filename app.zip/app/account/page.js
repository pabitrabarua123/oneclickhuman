import ProfileDetailsPage from "./index";

export const metadata = {
  title: "Profile Details - OneClickHuman",
  description: "",
};

const ProfileDetailsLayout = () => {
  return (
    <>
      <ProfileDetailsPage />
    </>
  );
};

export default ProfileDetailsLayout;
