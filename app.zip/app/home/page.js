import HomePage from "./index";

const HomePageLayout = () => {
  return (
    <>
      <HomePage />
    </>
  );
};

export default HomePageLayout;
