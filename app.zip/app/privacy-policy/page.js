import PrivacyPolicyPage from "./index";

export const metadata = {
  title: "Privacy Policy || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const PrivacyPolicyLayout = () => {
  return (
    <>
      <PrivacyPolicyPage />
    </>
  );
};

export default PrivacyPolicyLayout;
