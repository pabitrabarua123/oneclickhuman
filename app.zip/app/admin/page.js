import Admin from "./index";

export const metadata = {
  title: "Admin | OneClickHuman",
  description: "",
};

const AdminLayout = () => {
  return (
    <>
      <Admin />
    </>
  );
};

export default AdminLayout;
