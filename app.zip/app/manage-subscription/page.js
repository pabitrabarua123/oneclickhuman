import ManageSubscriptionPage from "./index";

export const metadata = {
  title: "Manage Subscription | One Click Human",
  description: "",
};

const ManageSubscriptionLayout = () => {
  return (
    <>
      <ManageSubscriptionPage />
    </>
  );
};

export default ManageSubscriptionLayout;
