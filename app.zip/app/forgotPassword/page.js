import SignInPage from "./index";

export const metadata = {
  title: "Forgot Password || OneClickHuman",
  description: "",
};

const ForgotPassword = () => {
  return (
    <>
      <SignInPage />
    </>
  );
};

export default ForgotPassword;
