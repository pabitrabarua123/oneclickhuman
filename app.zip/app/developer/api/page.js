import StyleGuidePage from "./index";

export const metadata = {
  title: "API || OneClickHuman",
  description: "",
};

const StyleGuideLayout = () => {
  return (
    <>
      <StyleGuidePage />
    </>
  );
};

export default StyleGuideLayout;
