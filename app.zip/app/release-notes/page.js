import ReleaseNotesPage from "./index";

export const metadata = {
  title: "Release Notes - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const ReleaseNotesLayout = () => {
  return (
    <>
      <ReleaseNotesPage />
    </>
  );
};

export default ReleaseNotesLayout;
