import PlansBillingPage from "./index";

export const metadata = {
  title: "Plans & Billing - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const PlansBillingLayout = () => {
  return (
    <>
      <PlansBillingPage />
    </>
  );
};

export default PlansBillingLayout;
