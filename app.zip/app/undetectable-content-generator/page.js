import UndetectableContentGenerator from "./index";

export const metadata = {
  title: "Undetectable Content generator | OneClickHuman",
  description: "",
};

const UndetectableContentGeneratorLayout = () => {
  return (
    <>
      <UndetectableContentGenerator />
    </>
  );
};

export default UndetectableContentGeneratorLayout;
