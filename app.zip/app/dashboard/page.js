import DashboardPage from "./index";

export const metadata = {
  title: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const DashboardLayout = () => {
  return (
    <>
      <DashboardPage />
    </>
  );
};

export default DashboardLayout;
