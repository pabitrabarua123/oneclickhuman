import BlogPage from "./index";

export const metadata = {
  title: "Blog || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const BlogLayout = () => {
  return (
    <>
      <BlogPage />
    </>
  );
};

export default BlogLayout;
