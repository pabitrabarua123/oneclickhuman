import RoadmapPage from "./index";

export const metadata = {
  title: "Roadmap || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const RoadmapLayout = () => {
  return (
    <>
      <RoadmapPage />
    </>
  );
};

export default RoadmapLayout;
