import EmailGeneratorPage from "./index";

export const metadata = {
  title: "Email Generator - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const EmailGeneratorLayout = () => {
  return (
    <>
      <EmailGeneratorPage />
    </>
  );
};

export default EmailGeneratorLayout;
