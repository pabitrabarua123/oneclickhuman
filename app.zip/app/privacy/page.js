import PrivacyPolicyPage from "./index";

export const metadata = {
  title: "Privacy Policy || OneClickHuman",
  description: "",
};

const PrivacyPolicyLayout = () => {
  return (
    <>
      <PrivacyPolicyPage />
    </>
  );
};

export default PrivacyPolicyLayout;
