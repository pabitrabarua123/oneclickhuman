import SignInPage from "./index";

export const metadata = {
  title: "SingIn || OneClickHuman",
  description: "",
};

const SingInLayout = () => {
  return (
    <>
      <SignInPage />
    </>
  );
};

export default SingInLayout;
