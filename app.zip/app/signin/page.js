import SignInPage from "./index";

export const metadata = {
  title: "SingIn || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const SingInLayout = () => {
  return (
    <>
      <SignInPage />
    </>
  );
};

export default SingInLayout;
