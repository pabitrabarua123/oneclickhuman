import StyleGuidePage from "./index";

export const metadata = {
  title: "Style Guide || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const StyleGuideLayout = () => {
  return (
    <>
      <StyleGuidePage />
    </>
  );
};

export default StyleGuideLayout;
