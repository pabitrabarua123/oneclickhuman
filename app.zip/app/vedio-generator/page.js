import VedioGeneratorPage from "./index";

export const metadata = {
  title: "Vedio Generator - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const VedioGeneratorLayout = () => {
  return (
    <>
      <VedioGeneratorPage />
    </>
  );
};

export default VedioGeneratorLayout;
