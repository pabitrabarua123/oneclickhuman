import SuccessPage from "./index";

export const metadata = {
  title: "Payment Success - OneClickHuman",
  description: "",
};

const SuccessLayout = () => {
  return (
    <>
      <SuccessPage />
    </>
  );
};

export default SuccessLayout;
