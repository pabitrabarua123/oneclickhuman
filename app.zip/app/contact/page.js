import ContactPage from "./index";

export const metadata = {
  title: "Contact || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const ContactLayout = () => {
  return (
    <>
      <ContactPage />
    </>
  );
};

export default ContactLayout;
