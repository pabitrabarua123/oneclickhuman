import NotificationPage from "./index";

export const metadata = {
  title: "Notification - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const NotificationLayout = () => {
  return (
    <>
      <NotificationPage />
    </>
  );
};

export default NotificationLayout;
