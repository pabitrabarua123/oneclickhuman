import TermsPolicyPage from "./index";

export const metadata = {
  title: "Terms and Policy - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const TermsPolicyLayout = () => {
  return (
    <>
      <TermsPolicyPage />
    </>
  );
};

export default TermsPolicyLayout;
