import ApplicationPage from "./index";

export const metadata = {
  title: "Applications - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const ApplicationLayout = () => {
  return (
    <>
      <ApplicationPage />
    </>
  );
};

export default ApplicationLayout;
