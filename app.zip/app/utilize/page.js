import UtilizePage from "./index";

export const metadata = {
  title: "How to use || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const UtilizeLayout = () => {
  return (
    <>
      <UtilizePage />
    </>
  );
};

export default UtilizeLayout;
