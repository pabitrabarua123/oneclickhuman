import TermsPolicyPage from "./index";

export const metadata = {
  title: "Terms of Service - OneClickHuman",
  description: "",
};

const TermsPolicyLayout = () => {
  return (
    <>
      <TermsPolicyPage />
    </>
  );
};

export default TermsPolicyLayout;
