import TeamPage from "./index";

export const metadata = {
  title: "Team || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
  description: "ChatenAI || ChatenAI - AI SaaS Website NEXTJS14 UI Kit",
};

const TeamLayout = () => {
  return (
    <>
      <TeamPage />
    </>
  );
};

export default TeamLayout;
