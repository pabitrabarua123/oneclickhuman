import SignUpPage from "./index";

export const metadata = {
  title: "SingUp || OneClickHuman",
  description: "",
};

const SingUpLayout = () => {
  return (
    <>
      <SignUpPage />
    </>
  );
};

export default SingUpLayout;
