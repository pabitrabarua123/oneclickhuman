import UtilizePage from "./index";

export const metadata = {
  title: "Documentation - OneClickHuman",
  description: "",
};

const UtilizeLayout = () => {
  return (
    <>
      <UtilizePage />
    </>
  );
};

export default UtilizeLayout;
